<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "metro_practise";
    
    // Create connection
    $conn = new mysqli("localhost", "root", "", "metro-practise");
    
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $start_station = $_POST['start_station'];
        $end_station = $_POST['end_station'];
    
        // Get station ids
        $sql = "SELECT station_id FROM metro_stations WHERE station_name IN ('$start_station', '$end_station')";
        $result = $conn->query($sql);
    
        if ($result->num_rows == 2) {
            $stations = [];
            while($row = $result->fetch_assoc()) {                                                                                                                                                                      
                $stations[] = $row['station_id'];
            }
    
            // Find lines and positions for the stations
            $sql = "SELECT line_id, station_id, position, direction FROM line_stations WHERE station_id IN (" . implode(',', $stations) . ")";
            $result = $conn->query($sql);
    
            if ($result->num_rows >= 2) {
                $line_positions = [];
                while($row = $result->fetch_assoc()) {
                    $line_positions[$row['line_id']][$row['station_id']] = [
                        'position' => $row['position'],
                        'direction' => $row['direction']
                    ];
                    
                }
                    
                $total_distance = 0;
                $common_station_found = false;
    
                foreach ($line_positions as $line_id => $positions) {
                    if (count($positions) == 2) {
                        // Stations are on the same line
                        $start_position = min($positions[$stations[0]]['position'], $positions[$stations[1]]['position']);
                        $end_position = max($positions[$stations[0]]['position'], $positions[$stations[1]]['position']);
    
                        $sql = "SELECT SUM(distance_from_prev) AS total_distance FROM line_stations WHERE line_id = $line_id AND position BETWEEN $start_position AND $end_position";
                        $result = $conn->query($sql);
    
                        if ($row = $result->fetch_assoc()) {
                            $total_distance = $row['total_distance'];
                            break;
                        }
                    } else {
                        // Check if there's a common station
                        $common_station = array_intersect_key($positions, array_flip([$stations[0], $stations[1]]));
                        if (!empty($common_station)) {
                            $common_station_id = key($common_station);
                            $common_station_found = true;
                            $common_station_direction = $common_station[$common_station_id]['direction'];
    
                            // Calculate distance for the first part
                            $sql = "SELECT SUM(distance_from_prev) AS total_distance FROM line_stations WHERE line_id = $line_id AND position BETWEEN " . min($positions[$stations[0]]['position'], $positions[$common_station_id]['position']) . " AND " . max($positions[$stations[0]]['position'], $positions[$common_station_id]['position']) . " AND direction = '" . $positions[$stations[0]]['direction'] . "'";
                            $result = $conn->query($sql);
                            if ($row = $result->fetch_assoc()) {
                                $total_distance += $row['total_distance'];
                            }
    
                            // Calculate distance for the second part
                            $sql = "SELECT SUM(distance_from_prev) AS total_distance FROM line_stations WHERE line_id = $line_id AND position BETWEEN " . min($positions[$common_station_id]['position'], $positions[$stations[1]]['position']) . " AND " . max($positions[$common_station_id]['position'], $positions[$stations[1]]['position']) . " AND direction = '" . $positions[$stations[1]]['direction'] . "'";
                            $result = $conn->query($sql);
                            if ($row = $result->fetch_assoc()) {
                                $total_distance += $row['total_distance'];
                            }
                        }
                    }
                }
                echo $start_station."<br>";
                echo $end_station."<br>";
                echo $total_distance."<br>";
    
                if ($common_station_found) {
                    echo "Stations are on different lines without a common station in the path.";
                } else {
                    echo "The distance between $start_station and $end_station is $total_distance km.";
                }
            } else {
                echo "Stations not found on the same or different lines.";
            }
        } else {
            echo "Stations not found.";
        }
    }
    
    $conn->close();
?>